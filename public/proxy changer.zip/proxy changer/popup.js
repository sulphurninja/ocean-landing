function parseProxy(str) {
  const [ip, port, user, pass] = str.split(":");
  return { ip, port, user, pass };
}

function applyProxy(proxy) {
  chrome.runtime.getBackgroundPage(function(bg) {
    bg.setProxy(proxy.ip, proxy.port, proxy.user, proxy.pass);
  });
}

function clearProxy() {
  chrome.runtime.getBackgroundPage(function(bg) {
    bg.clearProxy();
  });
}

function loadProxies() {
  chrome.storage.local.get("proxies", function(data) {
    const proxyList = document.getElementById("proxyList");
    proxyList.innerHTML = "";
    (data.proxies || []).forEach((proxy, index) => {
      const div = document.createElement("div");
      div.className = "proxy-entry";
      const span = document.createElement("span");
      span.textContent = proxy;
      const useBtn = document.createElement("button");
      useBtn.textContent = "ON";
      useBtn.onclick = () => applyProxy(parseProxy(proxy));
      const delBtn = document.createElement("button");
      delBtn.textContent = "Delete";
      delBtn.onclick = () => deleteProxy(index);
      div.appendChild(span);
      div.appendChild(useBtn);
      div.appendChild(delBtn);
      proxyList.appendChild(div);
    });
  });
}

function saveProxy() {
  const input = document.getElementById("proxyInput").value;
  if (!input.includes(":")) return alert("Invalid format.");
  chrome.storage.local.get("proxies", function(data) {
    const proxies = data.proxies || [];
    proxies.push(input);
    chrome.storage.local.set({ proxies }, loadProxies);
  });
}

function deleteProxy(index) {
  chrome.storage.local.get("proxies", function(data) {
    const proxies = data.proxies || [];
    proxies.splice(index, 1);
    chrome.storage.local.set({ proxies }, loadProxies);
  });
}

document.getElementById("saveBtn").onclick = saveProxy;
document.getElementById("useHomeBtn").onclick = () => {
  clearProxy();
};
loadProxies();