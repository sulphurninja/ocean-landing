let config = {
  mode: "fixed_servers",
  rules: {
    singleProxy: {
      scheme: "http",
      host: "",
      port: 0
    },
    bypassList: ["localhost"]
  }
};

function setProxy(ip, port, username, password) {
  config.rules.singleProxy.host = ip;
  config.rules.singleProxy.port = parseInt(port);
  chrome.proxy.settings.set({ value: config, scope: "regular" }, function () {});

  chrome.webRequest.onAuthRequired.addListener(
    function(details, callbackFn) {
      callbackFn({authCredentials: {username: username, password: password}});
    },
    {urls: ["<all_urls>"]},
    ['blocking']
  );
}

function clearProxy() {
  chrome.proxy.settings.clear({scope: "regular"});
}