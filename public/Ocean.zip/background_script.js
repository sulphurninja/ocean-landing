// background_script.js - Complete updated version

let scriptActivated = false, tabDetails, status_updates = {};

function getMsg(t, e) {
  return {
    msg: { type: t, data: e },
    sender: "popup",
    id: "irctc"
  };
}

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Background script received message:", request);

  // First check if it's a valid IRCTC message
  if (request.id !== "irctc") {
    console.error("Invalid message ID");
    sendResponse("Invalid Id");
    return false;
  }

  // Now check the message type
  if (request.msg && request.msg.type === "solveCaptcha") {
    console.log("Processing captcha solving request");

    const base64Data = request.msg.data.base64Data;
    console.log(`Received base64 data of length: ${base64Data.length} characters`);

    // Replace with your actual 2Captcha API key
    const twoCaptchaApiKey = "1d4ce5f5cbf267678e79e07b5d9bb2b1";

    // First, submit the captcha to 2Captcha
    fetch(`https://2captcha.com/in.php?key=${twoCaptchaApiKey}&method=base64&body=${encodeURIComponent(base64Data)}&json=1`)
      .then(response => response.json())
      .then(data => {
        console.log("2Captcha submission response:", data);

        if (data.status === 1) {
          const captchaId = data.request;
          console.log("2Captcha task created with ID:", captchaId);

          // Now poll for the result
          pollFor2CaptchaResult(captchaId, twoCaptchaApiKey, sendResponse);
        } else {
          console.error("2Captcha error:", data.request);
          sendResponse({
            success: false,
            error: data.request
          });
        }
      })
      .catch(error => {
        console.error("Error submitting to 2Captcha:", error.message);
        sendResponse({
          success: false,
          error: error.message
        });
      });

    // Return true to indicate that we'll call sendResponse asynchronously
    return true;
  }
  // Handle other message types
  else if (request.msg) {
    let msgType = request.msg.type,
        msgData = request.msg.data;

    if (msgType === "activate_script") {
      chrome.tabs.create(
        { url: "https://www.irctc.co.in/nget/train-search" },
        (t) => {
          tabDetails = t;
          chrome.scripting.executeScript({
            target: { tabId: t.id },
            files: ["./content_script.js"]
          });
        }
      );
      sendResponse("Script activated");
    } else if (msgType === "status_update") {
      if (!status_updates[sender.id]) {
        status_updates[sender.id] = [];
      }
      status_updates[sender.id].push({
        sender: sender,
        data: msgData
      });
      sendResponse("Status update received");
    } else {
      sendResponse("Something went wrong");
    }
    return false;
  } else {
    console.error("Unknown message format", request);
    sendResponse("Unknown message format");
    return false;
  }
});

// Function to poll for 2Captcha result
function pollFor2CaptchaResult(captchaId, apiKey, sendResponse, attemptCount = 0) {
  if (attemptCount > 30) {
    console.error("Max polling attempts reached");
    sendResponse({
      success: false,
      error: "Max polling attempts reached"
    });
    return;
  }

  // Wait at least 5 seconds before first poll (2Captcha recommendation)
  const delay = attemptCount === 0 ? 5000 : 2000;

  setTimeout(() => {
    console.log(`Polling 2Captcha for result, attempt ${attemptCount + 1}...`);

    fetch(`https://2captcha.com/res.php?key=${apiKey}&action=get&id=${captchaId}&json=1`)
      .then(response => response.json())
      .then(data => {
        console.log("2Captcha result response:", data);

        if (data.status === 1) {
          // Captcha solved successfully
          const captchaText = data.request;
          console.log("2Captcha result:", captchaText);

          sendResponse({
            success: true,
            text: captchaText
          });
        } else if (data.request === "CAPCHA_NOT_READY") {
          // Captcha is not ready yet, continue polling
          pollFor2CaptchaResult(captchaId, apiKey, sendResponse, attemptCount + 1);
        } else {
          // Error occurred
          console.error("2Captcha error:", data.request);
          sendResponse({
            success: false,
            error: data.request
          });
        }
      })
      .catch(error => {
        console.error("Error checking 2Captcha result:", error.message);

        if (attemptCount < 5) {
          pollFor2CaptchaResult(captchaId, apiKey, sendResponse, attemptCount + 1);
        } else {
          sendResponse({
            success: false,
            error: error.message
          });
        }
      });
  }, delay);
}

// Handle tab updates for content script communication
chrome.tabs.onUpdated.addListener((t, e, s) => {
  if (t === tabDetails?.id && e?.status === "complete") {
    if (s.url.includes("booking/train-list")) {
      chrome.tabs.sendMessage(tabDetails.id, getMsg("selectJourney"));
    } else if (s.url.includes("booking/psgninput")) {
      chrome.tabs.sendMessage(tabDetails.id, getMsg("fillPassengerDetails"));
    } else if (s.url.includes("booking/reviewBooking")) {
      chrome.tabs.sendMessage(tabDetails.id, getMsg("reviewBooking"));
    } else if (s.url.includes("payment/bkgPaymentOptions")) {
      chrome.tabs.sendMessage(tabDetails.id, getMsg("bkgPaymentOptions"));
    }
  }
});

// Handle extension installation
chrome.runtime.onInstalled.addListener((t) => {
  if (t.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.tabs.create({ url: "https://oceantatkal.vercel.app" });
  }
});
