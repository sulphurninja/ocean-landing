// main.js - Simplified version without version checking or announcements

document.getElementById("openPopupTab").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
});

(function () {
  const interval = setInterval(() => {
    const checkbox = document.getElementById('clearCheckbox');
    const input1 = document.getElementById('irctc-login');
    const input2 = document.getElementById('irctc-password');
    if (!checkbox || !input1 || !input2) return;
    clearInterval(interval);

    const savedState = localStorage.getItem('irctcClearCheckbox');
    if (savedState === 'checked') {
      checkbox.checked = true;
      clearAndDisableInputs();
    }

    checkbox.addEventListener('change', function () {
      if (checkbox.checked) {
        clearAndDisableInputs();
        localStorage.setItem('irctcClearCheckbox', 'checked');
      } else {
        input1.disabled = false;
        input2.disabled = false;
        localStorage.setItem('irctcClearCheckbox', 'unchecked');
      }
    });

    function clearAndDisableInputs() {
      manuallyClear(input1);
      manuallyClear(input2);
      input1.disabled = true;
      input2.disabled = true;
    }

    function manuallyClear(input) {
      input.value = '';
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }, 300);
})();

document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["plan_expiry"], (result) => {
    const expiryElement = document.getElementById("UserPlanExpairy");
    if (expiryElement && result.plan_expiry !== undefined) {
      if (result.plan_expiry) {
        expiryElement.textContent = result.plan_expiry;
        const expiryDate = new Date(result.plan_expiry);
        const today = new Date();
        expiryElement.style.color = today <= expiryDate ? "green" : "red";
      } else {
        expiryElement.textContent = "User Not Found";
        expiryElement.style.color = "orange";
      }
    }
  });
});

document.addEventListener('DOMContentLoaded', function () {
  const checkbox = document.getElementById('submitBtn2autoClickCheckbox');
  chrome.storage.sync.get(['submitBtn2autoClickEnabled'], function (result) {
    checkbox.checked = result.submitBtn2autoClickEnabled || false;
  });

  checkbox.addEventListener('change', function () {
    chrome.storage.sync.set({ submitBtn2autoClickEnabled: checkbox.checked }, function () {
      console.log('Setting saved:', checkbox.checked);
    });
  });
});

document.addEventListener("DOMContentLoaded", function () {
  var input = document.getElementById("cardexpiry");
  if (input) {
    input.addEventListener("input", function (e) {
      var val = e.target.value.replace(/\D/g, "");
      if (val.length > 4) val = val.slice(0, 4);
      if (val.length >= 3) {
        val = val.slice(0, 2) + "/" + val.slice(2);
      }
      e.target.value = val;
    });
  }
});
