let user_data = {};
GetVpa();
let intervalID = "";
let intervalID1 = "";

function addDelay(milliseconds) {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}

function hdfcPgHandler() {
  intervalID = setInterval(function(){
    if(!IsInPrograss()) {
      console.log("HDFC bank startt");
    }
  }, 200);

  intervalID1 = setInterval(function(){
    if(!IsInPrograss1()) {
      console.log("Fill data start");

      // Fill card details
      const cardno = document.getElementById("card_no");
      cardno.value = user_data["other_preferences"]["cardnumber"];
      cardno.dispatchEvent(new Event("input"));
      cardno.dispatchEvent(new Event("change"));

      const name = document.getElementById("name");
      name.value = user_data["other_preferences"]["cardholder"];
      name.dispatchEvent(new Event("input"));
      name.dispatchEvent(new Event("change"));

      const OtherDebitcvvHideShow = document.getElementById("other_debit_cvv_no");
      OtherDebitcvvHideShow.value = user_data["other_preferences"]["cardcvv"];
      OtherDebitcvvHideShow.dispatchEvent(new Event("input"));
      OtherDebitcvvHideShow.dispatchEvent(new Event("change"));

      console.log('exp Month', user_data["other_preferences"]["cardexpiry"].split('/')[0]);
      console.log('exp Year', user_data["other_preferences"]["cardexpiry"].split('/')[1]);

      const expmonth = document.getElementById("expMonthSelect");
      expmonth.value = Number(user_data["other_preferences"]["cardexpiry"].split('/')[0]);
      expmonth.dispatchEvent(new Event("input"));
      expmonth.dispatchEvent(new Event("change"));

      const expYearSelect = document.getElementById("expYearSelect");
      expYearSelect.value = "20" + user_data["other_preferences"]["cardexpiry"].split('/')[1];
      expYearSelect.dispatchEvent(new Event("input"));
      expYearSelect.dispatchEvent(new Event("change"));

      // Solve captcha
      solveCaptchaWithTrueCaptcha();

      console.log("END");
    }
  }, 200);
}

function IsInPrograss() {
  console.log("wait for page");
  document.querySelectorAll(".payment_mode")[0].click();
  addDelay(200);
  document.querySelectorAll("#other_debit")[0].click();
  if(document.getElementById("captchaDiv").style.display != "none") {
    console.log("Page loaded.");
    clearInterval(intervalID);
    return false;
  }
  return true;
}

function IsInPrograss1() {
  console.log("wait for captcha page");
  if(document.getElementById("captchaDiv").style.display != "none") {
    console.log("captcha Page loaded.");
    clearInterval(intervalID1);
    return false;
  }
  return true;
}

function GetVpa() {
  console.log("GetVpa");
  chrome.storage.local.get(null, (result) => {
    user_data = result;
    if (document.readyState !== 'loading') {
      hdfcPgHandler();
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        hdfcPgHandler();
      });
    }
  });
}
let captchaRetry = 0
function getCaptchaTC() {
  if (captchaRetry < 0x64) {
    console.log("getCaptchaTC");
    captchaRetry += 0x1;
    const _0x2df0e6 = document.querySelector(".captcha-img");
    if (_0x2df0e6) {
      const _0x1001e9 = new XMLHttpRequest();
      const _0x1eb805 = _0x2df0e6.src.substr(0x16);
      const _0x41e6f9 = JSON.stringify({
        'client': "chrome extension",
        'location': "https://www.irctc.co.in/nget/train-search",
        'version': '0.3.8',
        'case': "mixed",
        'promise': "true",
        'extension': true,
        'userid': "Umesh1978",
        'apikey': "5syUTBsSDaocZBzfC7LC",
        'data': _0x1eb805
      });
      _0x1001e9.open('POST', "https://api.apitruecaptcha.org/one/gettext", false);
      _0x1001e9.onload = function () {
        if (0xc8 != _0x1001e9.status) {
          console.log("Error " + _0x1001e9.status + ": " + _0x1001e9.statusText);
          console.log(_0x1001e9.response);
        } else {
          let _0x1c91ad = '';
          const _0x249c7f = document.querySelector("#captcha");
          _0x1c91ad = JSON.parse(_0x1001e9.response).result;
          console.log("Org text", _0x1c91ad);
          const _0x1dd512 = Array.from(_0x1c91ad.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0x5bbeef = '';
          for (const _0x7babcb of _0x1dd512) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x7babcb)) {
            _0x5bbeef += _0x7babcb;
          }
          _0x249c7f.value = _0x5bbeef;
          if ('' == _0x1c91ad) {
            console.log("Null captcha text from api");
            document.getElementsByClassName("glyphicon glyphicon-repeat")[0x0].parentElement.click();
            setTimeout(() => {
              getCaptchaTC();
            }, 0x1f4);
          }
          _0x249c7f.dispatchEvent(new Event("input"));
          _0x249c7f.dispatchEvent(new Event("change"));
          _0x249c7f.focus();
          const _0x3f1465 = document.querySelector("app-login");
          const _0x38b306 = document.querySelector("#divMain > div > app-review-booking > p-toast");
          let _0x1438c7 = new MutationObserver(_0x40ea83 => {
            if (_0x3f1465 && _0x3f1465.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect loginCaptcha");
              _0x1438c7.disconnect();
            }
            if (_0x38b306 && _0x38b306.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect reviewCaptcha");
              _0x1438c7.disconnect();
            }
          });
          if (_0x3f1465) {
            console.log("observe loginCaptcha");
            _0x1438c7.observe(_0x3f1465, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (_0x38b306) {
            console.log("observe reviewCaptcha");
            _0x1438c7.observe(_0x38b306, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (undefined !== user_data.other_preferences.CaptchaSubmitMode && 'A' == user_data.other_preferences.CaptchaSubmitMode) {
            console.log("Auto submit captcha");
            const _0x4340f9 = document.querySelector("#divMain > app-login");
            if (_0x4340f9) {
              const _0x12b22b = _0x4340f9.querySelector("button[type='submit'][class='search_btn train_Search']");
              const _0x18ac5b = _0x4340f9.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']");
              const _0x4acc95 = _0x4340f9.querySelector("input[type='text'][formcontrolname='userid']");
              const _0x3fe9e5 = _0x4340f9.querySelector("input[type='password'][formcontrolname='password']");
              if ('' != _0x4acc95.value && '' != _0x3fe9e5.value) {
                console.log("Submit login info and captcha");
                setTimeout(() => {
                  try {
                    _0x12b22b.click();
                  } catch (_0x5b42d9) {}
                  try {
                    _0x18ac5b.click();
                  } catch (_0x142b8a) {}
                }, 0x1f4);
              } else {
                alert("Unable to auto submit loging info, username and password not filled,please submit manually");
              }
            }
            reviewPage = document.querySelector("#divMain > div > app-review-booking");
            if (reviewPage) {
              console.log("reviewPage", reviewPage);
              if ('' != document.querySelector("#captcha").value) {
                const _0x4190fc = document.querySelector(".btnDefault.train_Search");
                if (_0x4190fc) {
                  setTimeout(() => {
                    console.log("Confirm berth", user_data.other_preferences.confirmberths);
                    if (user_data.other_preferences.confirmberths) {
                      if (document.querySelector(".AVAILABLE")) {
                        console.log("Seats available");
                        _0x4190fc.click();
                      } else {
                        if (0x1 != confirm("No seats Available, Do you still want to continue booking?")) {
                          return void console.log("No Seats available, STOP");
                        }
                        console.log("No Seats available, still Go ahead");
                        _0x4190fc.click();
                      }
                    } else {
                      _0x4190fc.click();
                    }
                  }, 0x1f4);
                }
              } else {
                alert("Captcha automatically not filled, submit manually");
              }
            }
          } else {
            console.log("Manual captcha submission");
          }
        }
      };
      _0x1001e9.onerror = function () {
        console.log("Captcha API Request failed");
      };
      _0x1001e9.send(_0x41e6f9);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptchaTC();
      }, 0x3e8);
    }
  }
}
