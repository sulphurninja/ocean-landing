let finalData = {
  'irctc_credentials': {},
  'subs_credentials': {},
  'journey_details': {},
  'passenger_details': [],
  'travel_preferences': {},
  'other_preferences': {},
  'vpa': {}
};
function autocompleteSourcDstTrain(_0x49f031, _0x29c0c6, _0x5a47cd) {
  var _0x97be7a;
  function _0x232906(_0x1db844) {
    if (!_0x1db844) {
      return false;
    }
    !function (_0x2ce6b1) {
      for (var _0x328eb8 = 0x0; _0x328eb8 < _0x2ce6b1.length; _0x328eb8++) {
        _0x2ce6b1[_0x328eb8].classList.remove('autocomplete-active');
      }
    }(_0x1db844);
    if (_0x97be7a >= _0x1db844.length) {
      _0x97be7a = 0x0;
    }
    if (_0x97be7a < 0x0) {
      _0x97be7a = _0x1db844.length - 0x1;
    }
    _0x1db844[_0x97be7a].classList.add("autocomplete-active");
  }
  function _0x291df5(_0x1bb0e8) {
    var _0x5d5472 = document.getElementsByClassName("autocomplete-items");
    for (var _0x530f30 = 0x0; _0x530f30 < _0x5d5472.length; _0x530f30++) {
      if (_0x1bb0e8 != _0x5d5472[_0x530f30] && _0x1bb0e8 != _0x49f031) {
        _0x5d5472[_0x530f30].parentNode.removeChild(_0x5d5472[_0x530f30]);
      }
    }
  }
  _0x49f031.addEventListener("input", function (_0x2db9fb) {
    var _0x44412e;
    var _0x1e359d;
    var _0xffd5e1;
    var _0x25fdbd = this.value;
    _0x291df5();
    if (!_0x25fdbd) {
      return false;
    }
    _0x97be7a = -0x1;
    (_0x44412e = document.createElement("DIV")).setAttribute('id', this.id + "autocomplete-list");
    _0x44412e.setAttribute("class", "autocomplete-items");
    this.parentNode.appendChild(_0x44412e);
    for (_0xffd5e1 = 0x0; _0xffd5e1 < _0x29c0c6.length; _0xffd5e1++) {
      if (_0x29c0c6[_0xffd5e1].toUpperCase().includes(_0x25fdbd.toUpperCase())) {
        (_0x1e359d = document.createElement("DIV")).innerHTML = "<strong>" + _0x29c0c6[_0xffd5e1].substr(0x0, _0x25fdbd.length) + "</strong>";
        _0x1e359d.innerHTML += _0x29c0c6[_0xffd5e1].substr(_0x25fdbd.length);
        _0x1e359d.innerHTML += "<input type='hidden' value='" + _0x29c0c6[_0xffd5e1] + "'>";
        _0x1e359d.addEventListener("click", function (_0x5346f0) {
          _0x49f031.value = this.getElementsByTagName('input')[0x0].value;
          if ("SOURCE" == _0x5a47cd) {
            finalData.journey_details.from = this.getElementsByTagName("input")[0x0].value;
          }
          if ("DEST" == _0x5a47cd) {
            finalData.journey_details.destination = this.getElementsByTagName("input")[0x0].value;
          }
          if ("TRAIN" == _0x5a47cd) {
            const _0x15f31f = this.getElementsByTagName("input")[0x0].value;
            finalData.journey_details["train-no"] = _0x15f31f.trim();
          }
          if ("BOARDING" == _0x5a47cd) {
            finalData.journey_details.boarding = this.getElementsByTagName('input')[0x0].value;
          }
          _0x291df5();
        });
        _0x44412e.appendChild(_0x1e359d);
      }
    }
  });
  _0x49f031.addEventListener('keydown', function (_0x11d142) {
    var _0x265c9c = document.getElementById(this.id + "autocomplete-list");
    if (_0x265c9c) {
      _0x265c9c = _0x265c9c.getElementsByTagName("div");
    }
    if (0x28 == _0x11d142.keyCode) {
      _0x97be7a++;
      _0x232906(_0x265c9c);
    } else if (0x26 == _0x11d142.keyCode) {
      _0x97be7a--;
      _0x232906(_0x265c9c);
    } else if (0xd == _0x11d142.keyCode) {
      _0x11d142.preventDefault();
      if (_0x97be7a > -0x1 && _0x265c9c) {
        _0x265c9c[_0x97be7a].click();
      }
    }
  });
  document.addEventListener("click", function (_0xd6260d) {
    _0x291df5(_0xd6260d.target);
  });
}
const stationData = [];
const stationList = [];
async function fetchStationData() {
  try {
    const _0x536516 = await fetch("https://shahidtatkal.github.io/accest/stationlist.json");
    if (!_0x536516.ok) {
      alert("Unable to fetch station data", "HTTP error! status: " + _0x536516.status);
      throw new Error("Unable to fetch station data", "HTTP error! status: " + _0x536516.status);
    }
    const _0x24680d = await _0x536516.json();
    stationData.push(..._0x24680d);
    for (let _0x394dbf in stationData) stationList.push(stationData[_0x394dbf].name + " - " + stationData[_0x394dbf].code);
    return stationList;
  } catch (_0x46a649) {
    console.error("Station date fetching error:", _0x46a649);
    alert("Station data fetching error:", _0x46a649);
    throw _0x46a649;
  }
}
async function fetchTrainData() {
  try {
    const _0x26efd6 = await fetch('https://shahidtatkal.github.io/accest/train_data.js');
    if (!_0x26efd6.ok) {
      alert("Unable to fetch train data", "HTTP error! status: " + _0x26efd6.status);
      throw new Error("Unable to fetch train data", "HTTP error! status: " + _0x26efd6.status);
    }
    return (await _0x26efd6.text()).split(/\r?\n/);
  } catch (_0x4fbed3) {
    console.error("Train data fetching error:", _0x4fbed3);
    alert("Train data fetching error:", _0x4fbed3);
    throw _0x4fbed3;
  }
}
function setIRCTCUsername(_0x28181c) {
  if (!finalData.irctc_credentials) {
    finalData.irctc_credentials = {};
  }
  finalData.irctc_credentials.user_name = _0x28181c.target.value;
  console.log('data-update', finalData);
}
function setIRCTCPassword(_0x365608) {
  finalData.irctc_credentials.password = _0x365608.target.value;
  console.log("data-update", finalData);
}
function setSubsUsername(_0x6e986c) {
  if (!finalData.subs_credentials) {
    finalData.subs_credentials = {};
  }
  finalData.subs_credentials.user_name = _0x6e986c.target.value;
  console.log("data-update", finalData);
}
function setSubsPassword(_0x3cc903) {
  finalData.subs_credentials.password = _0x3cc903.target.value;
  console.log("data-update", finalData);
}
function setFromStation(_0x158b4c) {
  finalData.journey_details.from = _0x158b4c.target.value.toUpperCase();
  document.querySelector("#from-station-input").value = _0x158b4c.target.value;
}
function setDestinationStation(_0x4a89ff) {
  finalData.journey_details.destination = _0x4a89ff.target.value.toUpperCase();
  document.querySelector("#destination-station-input").value = _0x4a89ff.target.value;
}
function setBoardingStation(_0x2ac5c7) {
  finalData.journey_details.boarding = _0x2ac5c7.target.value.toUpperCase();
  document.querySelector("#boarding-station-input").value = _0x2ac5c7.target.value;
}
function setJourneyClass(_0x56313b) {
  finalData.journey_details['class'] = _0x56313b.target.value;
  document.querySelector("#journey-class-input").value = _0x56313b.target.value;
}
function setQuota(_0x264d78) {
  finalData.journey_details.quota = _0x264d78.target.value;
  document.querySelector("#quota-input").value = _0x264d78.target.value;
}
function journeyDateChanged(_0x4cedc5) {
  finalData.journey_details.date = _0x4cedc5.target.value;
}
function setTrainNumber(_0x32e3ed) {
  finalData.journey_details["train-no"] = _0x32e3ed.target.value;
}
function setPassengerDetails(_0xb1c77e, _0x6984a4, _0x597631) {
  if (!finalData.passenger_details[_0x6984a4]) {
    finalData.passenger_details[_0x6984a4] = {};
  }
  finalData.passenger_details[_0x6984a4][_0xb1c77e.target.name] = "checkbox" === _0xb1c77e.target.type ? _0xb1c77e.target.checked : _0xb1c77e.target.value;
}
function setInfantDetails(_0x58c378, _0x55670b, _0x52833d) {
  if (!finalData.infant_details[_0x55670b]) {
    finalData.infant_details[_0x55670b] = {};
  }
  finalData.infant_details[_0x55670b][_0x58c378.target.name] = _0x58c378.target.value;
}
function setOtherPreferences(_0x1f0a3d) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x1f0a3d.target.name] = "checkbox" === _0x1f0a3d.target.type ? _0x1f0a3d.target.checked : _0x1f0a3d.target.value;
}
function setAutoCaptcha(_0xf3954b) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0xf3954b.target.name] = "checkbox" === _0xf3954b.target.type ? _0xf3954b.target.checked : _0xf3954b.target.value;
}
function setOtherPreferencesVpa(_0x57e9ba) {
  if (!finalData.vpa) {
    finalData.vpa = {};
  }
  finalData.vpa[_0x57e9ba.target.name] = _0x57e9ba.target.value;
}
function setpaymentMethod(_0x41831c) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences.paymentmethod = _0x41831c.target.value;
}
function setCaptchaSubmitMode(_0x128487) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences.CaptchaSubmitMode = _0x128487.target.value;
}
function setCardDetails(_0x1f1be8) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  if ("cardnumber" == _0x1f1be8.target.name) {
    finalData.other_preferences[_0x1f1be8.target.name] = _0x1f1be8.target.value;
  }
  if ("cardexpiry" == _0x1f1be8.target.name) {
    finalData.other_preferences[_0x1f1be8.target.name] = _0x1f1be8.target.value;
  }
  if ('cardcvv' == _0x1f1be8.target.name) {
    finalData.other_preferences[_0x1f1be8.target.name] = _0x1f1be8.target.value;
  }
  if ("cardholder" == _0x1f1be8.target.name) {
    finalData.other_preferences[_0x1f1be8.target.name] = _0x1f1be8.target.value;
  }
  if ("staticpassword" == _0x1f1be8.target.name) {
    finalData.other_preferences[_0x1f1be8.target.name] = _0x1f1be8.target.value;
  }
}
function setOtherPreferencesbooktime(_0x2e0570) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x2e0570.target.name] = _0x2e0570.target.value;
}
function setcardtype(_0xc1928e) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0xc1928e.target.name] = _0xc1928e.target.value;
}
function setMobileNumber(_0x102cf0) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x102cf0.target.name] = _0x102cf0.target.value;
}
function setTravelPreferences(_0x453da3) {
  if (!finalData.travel_preferences) {
    finalData.travel_preferences = {};
  }
  finalData.travel_preferences[_0x453da3.target.name] = "checkbox" === _0x453da3.target.type ? _0x453da3.target.checked : _0x453da3.target.value;
}
function setAvailabilyCheck(_0x16127a) {
  if (!finalData.travel_preferences) {
    finalData.travel_preferences = {};
  }
  finalData.travel_preferences[_0x16127a.target.name] = 'checkbox' === _0x16127a.target.type ? _0x16127a.target.checked : _0x16127a.target.value;
}
function setIrctcWallet(_0x93c3a1) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x93c3a1.target.name] = "checkbox" === _0x93c3a1.target.type ? _0x93c3a1.target.checked : _0x93c3a1.target.value;
}
function setTokenString(_0x4bbfa6) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x4bbfa6.target.name] = _0x4bbfa6.target.value;
}
function setprojectId(_0x81ce40) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x81ce40.target.name] = _0x81ce40.target.value;
}
function modifyUserData() {
  console.log("before modifyUserData");
  console.log(finalData);
  finalData.passenger_details = finalData.passenger_details?.["filter"](_0x4025fa => _0x4025fa.name?.["length"] > 0x0 && _0x4025fa.age?.["length"] > 0x0)?.["map"](_0x19299f => ({
    'name': _0x19299f.name,
    'age': _0x19299f.age,
    'gender': _0x19299f.gender ?? 'M',
    'berth': _0x19299f.berth ?? '',
    'nationality': 'IN',
    'food': _0x19299f.food ?? 'D',
    'passengerchildberth': _0x19299f.passengerchildberth ?? false
  })) ?? [];
  finalData.infant_details = finalData.infant_details?.["filter"](_0x4410b2 => _0x4410b2.name?.["length"] > 0x0)?.['map'](_0x1bbae8 => ({
    'name': _0x1bbae8.name,
    'age': _0x1bbae8.age ?? '0',
    'gender': _0x1bbae8.gender ?? 'M'
  })) ?? [];
  if (null == finalData.other_preferences.slbooktime) {
    finalData.other_preferences.slbooktime = document.getElementById("slbooktime").value;
  }
  if (null == finalData.other_preferences.acbooktime) {
    finalData.other_preferences.acbooktime = document.getElementById("acbooktime").value;
  }
  if (null == finalData.other_preferences.gnbooktime) {
    finalData.other_preferences.gnbooktime = document.getElementById("gnbooktime").value;
  }
  if (null == finalData.journey_details["class"]) {
    finalData.journey_details["class"] = document.getElementById("journey-class-input").value;
  }
  if (null == finalData.journey_details.quota) {
    finalData.journey_details.quota = document.getElementById('quota-input').value;
  }
  if (('TQ' === finalData.journey_details.quota || 'PT' === finalData.journey_details.quota) && finalData.passenger_details.length > 0x4) {
    alert("For tatkal quota Maximum 4 passengers allowed.");
  } else {
    if (null == finalData.journey_details.boarding) {
      finalData.journey_details.boarding = '';
    }
    if ('' == document.getElementById("boarding-station-input").value) {
      finalData.journey_details.boarding = '';
    }
    if (null == finalData.other_preferences.tokenString) {
      finalData.other_preferences.tokenString = '';
    }
    if (null == finalData.other_preferences.projectId) {
      finalData.other_preferences.projectId = '';
    }
    if (null == finalData.other_preferences.mobileNumber) {
      finalData.other_preferences.mobileNumber = '';
    }
    if (null == finalData.other_preferences.paymentmethod) {
      finalData.other_preferences.paymentmethod = document.getElementById("paymentMethod").value;
    }
    if (!document.getElementById("paymentMethod").value.includes("UPIID") || isValid_UPI_ID(document.getElementById("vpa").value)) {
      if (null == finalData.other_preferences.CaptchaSubmitMode) {
        finalData.other_preferences.CaptchaSubmitMode = document.getElementById("CaptchaSubmitMode").value;
      }
      if (null == finalData.other_preferences.cardnumber) {
        finalData.other_preferences.cardnumber = document.getElementById('cardnumber').value;
      }
      if (null == finalData.other_preferences.cardexpiry) {
        finalData.other_preferences.cardexpiry = document.getElementById("cardexpiry").value;
      }
      if (null == finalData.other_preferences.cardcvv) {
        finalData.other_preferences.cardcvv = document.getElementById("cardcvv").value;
      }
      if (null == finalData.other_preferences.cardholder) {
        finalData.other_preferences.cardholder = document.getElementById("cardholder").value;
      }
      if (null == finalData.other_preferences.cardtype) {
        finalData.other_preferences.cardtype = document.getElementById('cardtype').value;
      }
      if (null == finalData.other_preferences.staticpassword) {
        finalData.other_preferences.staticpassword = document.getElementById("staticpassword").value;
      }
      if (null == finalData.travel_preferences.AvailabilityCheck) {
        finalData.travel_preferences.AvailabilityCheck = 'A';
      }
      if (null == finalData.journey_details['train-no']) {
        console.log("Set default train nr.");
        finalData.journey_details["train-no"] = "00000- DEFAULT";
      }
      console.log("after modifyUserData");
      console.log(finalData);
      chrome.storage.local.set(finalData);
      alert("Data saved successfully");
    } else {
      alert("Valid UPI ID is required for selected payment method.");
    }
  }
}
function isValid_UPI_ID(_0x1cd641) {
  let _0xb2e84 = new RegExp("^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$");
  return null != _0x1cd641 && 0x1 == _0xb2e84.test(_0x1cd641);
}
async function getDeviceId() {
  const {
    deviceId: _0x5257c4
  } = await chrome.storage.local.get('deviceId');
  if (!_0x5257c4) {
    const _0x483a50 = crypto.randomUUID();
    await chrome.storage.local.set({
      'deviceId': _0x483a50
    });
    return _0x483a50;
  }
  return _0x5257c4;
}
function loadUserData() {
  chrome.storage.local.get(null, _0x34a0d0 => {
    if (_0x34a0d0.plan_expiry) {
      const _0x88c74 = document.getElementById('UserPlanExpairy');
      if (_0x88c74) {
        const _0x6a1f50 = new Date(_0x34a0d0.plan_expiry);
        _0x88c74.textContent = _0x6a1f50.toISOString().split('T')[0x0];
        _0x88c74.style.color = new Date() > _0x6a1f50 ? "red" : "green";
      }
    }
    console.log("loadUserData");
    console.log(_0x34a0d0);
    if (0x0 !== Object.keys(_0x34a0d0).length) {
      document.querySelector("#irctc-login").value = _0x34a0d0.irctc_credentials.user_name;
      document.querySelector("#irctc-password").value = _0x34a0d0.irctc_credentials.password;
      document.querySelector('#subscriber-username').value = _0x34a0d0.subs_credentials.user_name;
      document.querySelector('#subscriber-password').value = _0x34a0d0.subs_credentials.password;
      document.querySelector("#from-station-input").value = _0x34a0d0.journey_details.from;
      document.querySelector('#destination-station-input').value = _0x34a0d0.journey_details.destination;
      document.querySelector("#boarding-station-input").value = _0x34a0d0.journey_details.boarding;
      document.querySelector('#journey-date').value = _0x34a0d0.journey_details.date;
      document.querySelector("#journey-class-input").value = _0x34a0d0.journey_details['class'];
      document.querySelector("#quota-input").value = _0x34a0d0.journey_details.quota;
      document.querySelector("#train-no").value = '' + _0x34a0d0.journey_details["train-no"];
      _0x34a0d0.passenger_details.forEach((_0x98e704, _0x4eec52) => {
        document.querySelector("#passenger-name-" + (_0x4eec52 + 0x1)).value = _0x98e704.name ?? '';
        document.querySelector('#age-' + (_0x4eec52 + 0x1)).value = _0x98e704.age ?? '';
        document.querySelector("#passenger-gender-" + (_0x4eec52 + 0x1)).value = _0x98e704.gender ?? 'M';
        document.querySelector('#passenger-berth-' + (_0x4eec52 + 0x1)).value = _0x98e704.berth ?? '';
        document.querySelector("#passenger-food-" + (_0x4eec52 + 0x1)).value = _0x98e704.food ?? '';
        document.querySelector("#passengerchildberth" + (_0x4eec52 + 0x1)).checked = _0x98e704.passengerchildberth ?? false;
      });
      _0x34a0d0.infant_details.forEach((_0x12c941, _0x4985fe) => {
        document.querySelector('#Infant-name-' + (_0x4985fe + 0x1)).value = _0x12c941.name ?? '';
        document.querySelector("#Infant-age-" + (_0x4985fe + 0x1)).value = _0x12c941.age ?? '0';
        document.querySelector("#Infant-gender-" + (_0x4985fe + 0x1)).value = _0x12c941.gender ?? 'M';
      });
      if (_0x34a0d0.travel_preferences?.['travelInsuranceOpted']) {
        document.querySelector("#travelInsuranceOpted-" + ('yes' === _0x34a0d0.travel_preferences?.["travelInsuranceOpted"] ? 0x1 : 0x2)).checked = true;
      }
      if (_0x34a0d0.travel_preferences.prefcoach) {
        document.querySelector("#prefcoach").value = _0x34a0d0.travel_preferences.prefcoach ?? '';
      }
      if (_0x34a0d0.travel_preferences.reservationchoice) {
        document.querySelector("#reservationchoice").value = _0x34a0d0.travel_preferences.reservationchoice ?? '';
      }
      try {
        if (_0x34a0d0.travel_preferences?.["AvailabilityCheck"]) {
          document.querySelector("#AvailabilityCheck-" + ('A' === _0x34a0d0.travel_preferences?.["AvailabilityCheck"] ? 0x1 : 'M' === _0x34a0d0.travel_preferences?.['AvailabilityCheck'] ? 0x2 : 'I' === _0x34a0d0.travel_preferences?.["AvailabilityCheck"] ? 0x3 : 0x1)).checked = true;
        } else {
          console.log("Load user data - set availability A - if not defined");
          chrome.storage.local.set({
            'travel_preferences': {
              'AvailabilityCheck': 'A'
            }
          }, () => {
            console.log("set AvailabilityCheck A");
          });
        }
      } catch {
        console.log("error getting availability check");
      }
      if (Object.keys(_0x34a0d0.other_preferences).length > 0x0) {
        document.querySelector("#autoUpgradation").checked = _0x34a0d0.other_preferences.autoUpgradation ?? false;
        document.querySelector('#confirmberths').checked = _0x34a0d0.other_preferences.confirmberths ?? false;
        document.querySelector("#acbooktime").value = _0x34a0d0.other_preferences.acbooktime;
        document.querySelector('#slbooktime').value = _0x34a0d0.other_preferences.slbooktime;
        if (_0x34a0d0.other_preferences.hasOwnProperty('gnbooktime')) {
          document.querySelector("#gnbooktime").value = _0x34a0d0.other_preferences.gnbooktime;
        } else {
          console.log("Load user data - set GN book time - if not defined");
          chrome.storage.local.set({
            'other_preferences': {
              'gnbooktime': '07:59:59'
            }
          }, () => {
            console.log("set gnbooktime");
          });
          document.querySelector("#gnbooktime").value = '07:59:59';
        }
        document.querySelector('#mobileNumber').value = _0x34a0d0.other_preferences.mobileNumber;
        document.querySelector("#paymentmethod").value = _0x34a0d0.other_preferences.paymentmethod;
        document.querySelector('#CaptchaSubmitMode').value = _0x34a0d0.other_preferences.CaptchaSubmitMode;
        document.querySelector('#autoCaptcha').checked = _0x34a0d0.other_preferences.autoCaptcha ?? false;
        document.querySelector("#psgManual").checked = _0x34a0d0.other_preferences.psgManual ?? false;
        document.querySelector('#paymentManual').checked = _0x34a0d0.other_preferences.paymentManual ?? false;
        document.querySelector('#tokenString').value = _0x34a0d0.other_preferences.tokenString;
        document.querySelector('#projectId').value = _0x34a0d0.other_preferences.projectId;
      }
      if (Object.keys(_0x34a0d0.vpa).length > 0x0 && '' !== _0x34a0d0.vpa.vpa) {
        console.log("load vpa", _0x34a0d0.vpa.vpa);
        document.querySelector("#vpa").hidden = false;
        document.querySelector('#vpa').value = _0x34a0d0.vpa.vpa;
      }
      if (!('DBTCRD' != _0x34a0d0.other_preferences.paymentmethod && "DBTCRDI" != _0x34a0d0.other_preferences.paymentmethod)) {
        document.getElementById("carddetails").hidden = false;
      }
      document.querySelector("#cardnumber").value = _0x34a0d0.other_preferences.cardnumber;
      document.querySelector("#cardexpiry").value = _0x34a0d0.other_preferences.cardexpiry;
      document.querySelector("#cardcvv").value = _0x34a0d0.other_preferences.cardcvv;
      document.querySelector("#cardholder").value = _0x34a0d0.other_preferences.cardholder;
      document.querySelector("#cardtype").value = _0x34a0d0.other_preferences.cardtype;
      document.querySelector("#staticpassword").value = _0x34a0d0.other_preferences.staticpassword;
      finalData = _0x34a0d0;
    }
  });
}
function getMsg(_0x274845, _0x304b2f) {
  return {
    'msg': {
      'type': _0x274845,
      'data': _0x304b2f
    },
    'sender': "popup",
    'id': "irctc"
  };
}
function saveForm() {
  if ('' != document.getElementById("subscriber-username").value && '' != document.getElementById("subscriber-password").value) {
    modifyUserData();
  } else {
    alert("subscriber username and password required");
  }
}
function clearData() {
  if (0x1 == confirm("Do you want to clear data?")) {
    chrome.storage.local.clear();
  }
}
function connectWithBg() {
  if (!finalData.subs_credentials?.["user_name"] || !finalData.subs_credentials?.["password"]) {
    return alert("Please enter valid subscriber credentials");
  }
  a();
}
function startScript() {
  chrome.runtime.sendMessage({
    'msg': {
      'type': "activate_script",
      'data': finalData
    },
    'sender': "popup",
    'id': "irctc"
  }, _0x337e94 => {
    console.log(_0x337e94, "activate_script response");
  });
}
async function a() {
  const _0x194bd0 = await getDeviceId();
  try {
    const _0x5c1578 = await fetch("https://oceantatkal.vercel.app/api/login", {
      'method': "POST",
      'headers': {
        'Content-Type': "application/json"
      },
      'body': JSON.stringify({
        'username': finalData.subs_credentials.user_name,
        'password': finalData.subs_credentials.password,
        'device_id': _0x194bd0
      })
    });
    if (!_0x5c1578.ok) {
      const _0x3a55b9 = await _0x5c1578.json();
      throw new Error(_0x3a55b9.error || "Authentication failed");
    }
    const _0x1c38fa = await fetch('https://oceantatkal.vercel.app/api/subscription?username=' + encodeURIComponent(finalData.subs_credentials.user_name));
    if (!_0x1c38fa.ok) {
      throw new Error("Failed to verify subscription");
    }
    const _0x127de3 = await _0x1c38fa.json();
    if (!_0x127de3.isActive) {
      throw new Error("Subscription expired or inactive");
    }
    const _0x591c38 = document.getElementById('UserPlanExpairy');
    if (_0x591c38) {
      const _0x1d5f7c = new Date(_0x127de3.expiry);
      _0x591c38.textContent = _0x1d5f7c.toLocaleDateString();
      _0x591c38.style.color = _0x1d5f7c > new Date() ? "green" : "red";
    }
    chrome.storage.local.set({
      'plan': 'A',
      'plan_expiry': _0x127de3.expiryDate
    }, () => {
      loader.classList.remove('fa', 'fa-spinner', 'fa-spin');
      startScript();
    });
  } catch (_0x13f229) {
    console.error("Auth error:", _0x13f229);
    loader.classList.remove('fa', "fa-spinner", "fa-spin");
    alert("Error: " + _0x13f229.message);
    chrome.storage.local.remove(["plan", "plan_expiry"]);
  }
}
function buyPlan() {
  const _0x111726 = document.getElementById("custom-popup");
  if (_0x111726) {
    _0x111726.remove();
  }
  const _0x325b07 = document.createElement("div");
  _0x325b07.id = "custom-popup";
  _0x325b07.style.position = "fixed";
  _0x325b07.style.top = '0';
  _0x325b07.style.left = '0';
  _0x325b07.style.width = "100%";
  _0x325b07.style.height = "100%";
  _0x325b07.style.backgroundColor = "rgba(0, 0, 0, 0.6)";
  _0x325b07.style.zIndex = '9999';
  _0x325b07.style.display = "flex";
  _0x325b07.style.justifyContent = "center";
  _0x325b07.style.alignItems = 'center';
  const _0x3e2556 = document.createElement("div");
  _0x3e2556.style.position = "relative";
  _0x3e2556.style.width = "90%";
  _0x3e2556.style.maxWidth = "800px";
  _0x3e2556.style.height = "80%";
  _0x3e2556.style.backgroundColor = "#fff";
  _0x3e2556.style.borderRadius = '10px';
  _0x3e2556.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)";
  _0x3e2556.style.overflow = 'hidden';
  const _0x35e86c = document.createElement('button');
  _0x35e86c.innerText = 'X';
  _0x35e86c.style.position = 'absolute';
  _0x35e86c.style.top = "10px";
  _0x35e86c.style.right = "15px";
  _0x35e86c.style.fontSize = '24px';
  _0x35e86c.style.background = 'none';
  _0x35e86c.style.border = "none";
  _0x35e86c.style.cursor = "pointer";
  _0x35e86c.onclick = () => _0x325b07.remove();
  const _0x39c956 = document.createElement("iframe");
  _0x39c956.src = '';
  _0x39c956.style.width = "100%";
  _0x39c956.style.height = '100%';
  _0x39c956.style.border = "none";
  _0x3e2556.appendChild(_0x35e86c);
  _0x3e2556.appendChild(_0x39c956);
  _0x325b07.appendChild(_0x3e2556);
  document.body.appendChild(_0x325b07);
}
function OpenSite() {
  window.open('', "_blank");
}
function showsubscriberpswd() {
  var _0xe1417a = document.getElementById("subscriber-password");
  if ("password" === _0xe1417a.type) {
    _0xe1417a.type = "text";
  } else {
    _0xe1417a.type = "password";
  }
}
function showirctcpswd() {
  var _0x5a0eaf = document.getElementById("irctc-password");
  if ("password" === _0x5a0eaf.type) {
    _0x5a0eaf.type = "text";
  } else {
    _0x5a0eaf.type = "password";
  }
}
function showhdfcpass() {
  var _0x543e25 = document.getElementById('staticpassword');
  if ("password" === _0x543e25.type) {
    _0x543e25.type = 'text';
  } else {
    _0x543e25.type = 'password';
  }
}
fetchStationData().then(_0x2c549c => {
  autocompleteSourcDstTrain(document.getElementById("from-station-input"), _0x2c549c, 'SOURCE');
  autocompleteSourcDstTrain(document.getElementById("destination-station-input"), _0x2c549c, 'DEST');
  autocompleteSourcDstTrain(document.getElementById("boarding-station-input"), _0x2c549c, "BOARDING");
});
fetchTrainData().then(_0x4845ff => {
  autocompleteSourcDstTrain(document.getElementById("train-no"), _0x4845ff, "TRAIN");
});
window.addEventListener("load", () => {
  loadUserData();
  document.querySelector("#irctc-login").addEventListener("change", setIRCTCUsername);
  document.querySelector("#irctc-password").addEventListener('change', setIRCTCPassword);
  document.querySelector("#subscriber-username").addEventListener("change", setSubsUsername);
  document.querySelector('#subscriber-password').addEventListener("change", setSubsPassword);
  document.querySelector("#journey-date").addEventListener("change", journeyDateChanged);
  document.querySelector("#journey-class-input").addEventListener("change", setJourneyClass);
  document.querySelector("#quota-input").addEventListener('change', setQuota);
  for (let _0x55798c = 0x0; _0x55798c < 0x6; _0x55798c++) {
    document.querySelector("#passenger-name-" + (_0x55798c + 0x1)).addEventListener("change", _0x45c65e => setPassengerDetails(_0x45c65e, _0x55798c, "passenger"));
    document.querySelector('#age-' + (_0x55798c + 0x1)).addEventListener('change', _0x2933e4 => setPassengerDetails(_0x2933e4, _0x55798c, "passenger"));
    document.querySelector("#passenger-gender-" + (_0x55798c + 0x1)).addEventListener("change", _0x407bbf => setPassengerDetails(_0x407bbf, _0x55798c, "passenger"));
    document.querySelector('#passenger-berth-' + (_0x55798c + 0x1)).addEventListener('change', _0x27484b => setPassengerDetails(_0x27484b, _0x55798c, "passenger"));
    document.querySelector("#passenger-food-" + (_0x55798c + 0x1)).addEventListener('change', _0x1c7885 => setPassengerDetails(_0x1c7885, _0x55798c, 'passenger'));
    document.querySelector("#passengerchildberth" + (_0x55798c + 0x1)).addEventListener("change", _0x548c3b => setPassengerDetails(_0x548c3b, _0x55798c, "passenger"));
  }
  for (let _0x7ee8ab = 0x0; _0x7ee8ab < 0x2; _0x7ee8ab++) {
    document.querySelector('#Infant-name-' + (_0x7ee8ab + 0x1)).addEventListener("change", _0x58e371 => setInfantDetails(_0x58e371, _0x7ee8ab, 'infant'));
    document.querySelector("#Infant-age-" + (_0x7ee8ab + 0x1)).addEventListener("change", _0x87cf46 => setInfantDetails(_0x87cf46, _0x7ee8ab, "infant"));
    document.querySelector("#Infant-gender-" + (_0x7ee8ab + 0x1)).addEventListener("change", _0x5a7a68 => setInfantDetails(_0x5a7a68, _0x7ee8ab, "infant"));
  }
  document.querySelector("#autoUpgradation").addEventListener("change", setOtherPreferences);
  document.querySelector("#autoCaptcha").addEventListener("change", setAutoCaptcha);
  document.querySelector("#psgManual").addEventListener("change", setAutoCaptcha);
  document.querySelector("#paymentManual").addEventListener("change", setAutoCaptcha);
  document.querySelector('#confirmberths').addEventListener("change", setOtherPreferences);
  document.querySelector("#vpa").addEventListener("change", setOtherPreferencesVpa);
  const _0x4ad957 = document.querySelector("#cardnumber");
  _0x4ad957.addEventListener("keyup", () => {
    let _0x524dd7 = _0x4ad957.value;
    _0x524dd7 = _0x524dd7.replace(/\s/g, '');
    if (Number(_0x524dd7)) {
      _0x524dd7 = _0x524dd7.match(/.{1,4}/g);
      _0x524dd7 = _0x524dd7.join(" ");
      _0x4ad957.value = _0x524dd7;
      finalData.other_preferences.cardnumber = _0x4ad957.value;
    }
  });
  document.querySelector("#cardexpiry").addEventListener("change", setCardDetails);
  document.querySelector("#cardcvv").addEventListener("change", setCardDetails);
  document.querySelector('#cardholder').addEventListener("change", setCardDetails);
  document.querySelector('#paymentMethod').addEventListener('change', setpaymentMethod);
  document.querySelector("#CaptchaSubmitMode").addEventListener("change", setCaptchaSubmitMode);
  document.querySelector("#cardtype").addEventListener("change", setcardtype);
  document.querySelector('#slbooktime').addEventListener("change", setOtherPreferencesbooktime);
  document.querySelector("#acbooktime").addEventListener("change", setOtherPreferencesbooktime);
  document.querySelector("#gnbooktime").addEventListener('change', setOtherPreferencesbooktime);
  document.querySelector("#mobileNumber").addEventListener("change", setMobileNumber);
  document.querySelector("#travelInsuranceOpted-1").addEventListener("change", setTravelPreferences);
  document.querySelector("#travelInsuranceOpted-2").addEventListener("change", setTravelPreferences);
  document.querySelector("#AvailabilityCheck-1").addEventListener('change', setAvailabilyCheck);
  document.querySelector("#AvailabilityCheck-2").addEventListener("change", setAvailabilyCheck);
  document.querySelector('#AvailabilityCheck-3').addEventListener("change", setAvailabilyCheck);
  document.querySelector("#tokenString").addEventListener("change", setTokenString);
  document.querySelector("#projectId").addEventListener("change", setprojectId);
  document.querySelector('#staticpassword').addEventListener("change", setprojectId);
  document.querySelector("#submit-btn").addEventListener("click", saveForm);
  document.querySelector("#load-btn-1").addEventListener("click", () => {
    buyPlan();
  });
  document.querySelector("#OpenSite").addEventListener("click", () => {
    OpenSite();
  });
  document.querySelector("#clear-btn").addEventListener("click", () => clearData());
  document.querySelector('#connect-btn').addEventListener("click", connectWithBg);
  document.querySelector("#showsubscriberpswd").addEventListener("click", showsubscriberpswd);
  document.querySelector("#showirctcpswd").addEventListener("click", showirctcpswd);
  document.querySelector('#showhdfcpass').addEventListener("click", showhdfcpass);
  document.querySelector('#reservationchoice').addEventListener("change", setTravelPreferences);
  document.querySelector("#prefcoach").addEventListener('change', setTravelPreferences);
});
