let user_data = {};
function getMsg(_0x3e77b3, _0x17a3af) {
  return {
    'msg': {
      'type': _0x3e77b3,
      'data': _0x17a3af
    },
    'sender': "content_script",
    'id': "irctc"
  };
}
function statusUpdate(_0x48f187) {
  chrome.runtime.sendMessage({
    'msg': {
      'type': 'status_update',
      'data': {
        'status': _0x48f187,
        'time': new Date().toString().split(" ")[0x4]
      }
    },
    'sender': "content_script",
    'id': "irctc"
  });
}
function classTranslator(_0x2d708a) {
  labletext = '1A' === _0x2d708a ? "AC First Class (1A)" : 'EV' === _0x2d708a ? "Vistadome AC (EV)" : 'EC' === _0x2d708a ? "Exec. Chair Car (EC)" : '2A' === _0x2d708a ? "AC 2 Tier (2A)" : '3A' === _0x2d708a ? "AC 3 Tier (3A)" : '3E' === _0x2d708a ? "AC 3 Economy (3E)" : 'CC' === _0x2d708a ? "AC Chair car (CC)" : 'SL' === _0x2d708a ? "Sleeper (SL)" : '2S' === _0x2d708a ? "Second Sitting (2S)" : 'None';
  return labletext;
}
function quotaTranslator(_0x2890ac) {
  if ('GN' === _0x2890ac) {
    labletext = "GENERAL";
  } else if ('TQ' === _0x2890ac) {
    labletext = "TATKAL";
  } else if ('PT' === _0x2890ac) {
    labletext = "PREMIUM TATKAL";
  } else if ('LD' === _0x2890ac) {
    labletext = "LADIES";
  } else if ('SR' === _0x2890ac) {
    labletext = "LOWER BERTH/SR.CITIZEN";
  } else {
    labletext;
  }
  return labletext;
}
function addDelay(_0x178984) {
  const _0x2b1e5e = Date.now();
  let _0x560719 = null;
  do {
    _0x560719 = Date.now();
  } while (_0x560719 - _0x2b1e5e < _0x178984);
}
chrome.runtime.onMessage.addListener((_0x15a2a4, _0x31df20, _0x175006) => {
  if ("irctc" !== _0x15a2a4.id) {
    return void _0x175006("Invalid Id");
  }
  const _0x4928fc = _0x15a2a4.msg.type;
  if ("selectJourney" === _0x4928fc) {
    console.log("selectJourney");
    popupbtn = document.querySelectorAll(".btn.btn-primary");
    if (popupbtn.length > 0x0) {
      popupbtn[0x1].click();
      console.log("Close last trxn popup");
    }
    const _0x3bafb3 = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
    console.log(user_data.journey_details["train-no"]);
    const _0x786022 = user_data.journey_details["train-no"];
    const _0x5834eb = _0x3bafb3.filter(_0x407228 => _0x407228.querySelector("div.train-heading").innerText.trim().includes(_0x786022.split('-')[0x0]))[0x0];
    if ('M' === user_data.travel_preferences.AvailabilityCheck) {
      return void alert("Please manually select train and click Book");
    }
    if ('A' === user_data.travel_preferences.AvailabilityCheck || 'I' === user_data.travel_preferences.AvailabilityCheck) {
      if (!_0x5834eb) {
        console.log("Precheck - Train not found for search criteria.");
        return void alert("Precheck - Train(" + _0x786022 + ") not found for search criteria. You can manually proceed or correct data and restart the process.");
      }
      const _0x734133 = classTranslator(user_data.journey_details["class"]);
      if (![..._0x5834eb.querySelectorAll("table tr td div.pre-avl")].filter(_0x3ea210 => _0x3ea210.querySelector("div").innerText === _0x734133)[0x0]) {
        console.log("Precheck - Selected Class not available in the train.");
        return void alert("Precheck - Selected Class not available in the train. You can manually proceed or correct data and restart the process.");
      }
    }
    const _0x499829 = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if ('A' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Automatically click");
      if ('TQ' === user_data.journey_details.quota || 'PT' === user_data.journey_details.quota || 'GN' === user_data.journey_details.quota) {
        console.log("Verify tatkal time");
        const _0x3bc9d1 = user_data.journey_details["class"];
        requiredTime = "00:00:00";
        current_time = "00:00:00";
        if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(_0x3bc9d1.toUpperCase())) {
          requiredTime = user_data.other_preferences.acbooktime;
        } else {
          requiredTime = user_data.other_preferences.slbooktime;
        }
        if ('GN' === user_data.journey_details.quota) {
          requiredTime = user_data.other_preferences.gnbooktime;
        }
        console.log("requiredTime", requiredTime);
        var _0x5ceb28 = 0x0;
        let _0x458439 = new MutationObserver(_0x2aeab7 => {
          current_time = new Date().toString().split(" ")[0x4];
          console.log("current_time", current_time);
          if (current_time > requiredTime) {
            _0x458439.disconnect();
            selectJourney();
          } else {
            if (0x0 == _0x5ceb28) {
              console.log("Inside wait counter 0 ");
              try {
                const _0x36f63d = document.createElement("div");
                _0x36f63d.textContent = "Please wait..Booking will automatically start at " + requiredTime;
                _0x36f63d.style.textAlign = "center";
                _0x36f63d.style.color = "white";
                _0x36f63d.style.height = "auto";
                _0x36f63d.style.fontSize = "20px";
                document.querySelector("#divMain > div > app-train-list > div> div > div > div.clearfix").insertAdjacentElement("afterend", _0x36f63d);
              } catch (_0x3a4b67) {
                console.log("wait time failed", _0x3a4b67.message);
              }
            }
            try {
              if (_0x5ceb28 % 0x2 == 0x0) {
                console.log("counter1", _0x5ceb28 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = 'green';
              } else {
                console.log("counter2", _0x5ceb28 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = "red";
              }
            } catch (_0x26d03f) {}
            _0x5ceb28 += 0x1;
            console.log("wait time");
          }
        });
        _0x458439.observe(_0x499829, {
          'childList': true,
          'subtree': true,
          'characterDataOldValue': true
        });
      } else {
        console.log("select journey GENERAL quota");
        selectJourney();
      }
    } else if ('I' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Immediately click");
      selectJourney();
    }
  } else {
    if ("fillPassengerDetails" === _0x4928fc) {
      console.log("fillPassengerDetails");
      fillPassengerDetails();
    } else {
      if ("reviewBooking" === _0x4928fc) {
        console.log("reviewBooking");
        try {
          chrome.storage.local.get(["plan"], _0x39ec5f => {
            console.log("Retrieved plan: ", _0x39ec5f.plan);
            if ('A' == _0x39ec5f.plan) {
              console.log("User have active plan");
            } else {
              alert("Please buy a suitable plan to use the extension.");
              try {
                document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
              } catch (_0xfab6fc) {
                window.location.href = "https://www.irctc.co.in/nget/train-search";
              }
            }
          });
        } catch (_0x1f5f42) {
          alert("Failed to validate plan. Please contact our support team");
          try {
            document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
          } catch (_0x12d5fa) {
            window.location.href = "https://www.irctc.co.in/nget/train-search";
          }
        }
        document.querySelector("#captcha").scrollIntoView({
          'behavior': "smooth",
          'block': "center",
          'inline': "nearest"
        });
        if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
          setTimeout(() => {
            getCaptchaTC();
          }, 0x1f4);
        } else {
          console.log("Manuall captcha filling");
          const _0x18f9fe = document.querySelector("#captcha");
          _0x18f9fe.value = 'X';
          _0x18f9fe.dispatchEvent(new Event("input"));
          _0x18f9fe.dispatchEvent(new Event("change"));
          _0x18f9fe.focus();
        }
      } else {
        if ("bkgPaymentOptions" === _0x4928fc) {
          addDelay(0xc8);
          console.log("bkgPaymentOptions");
          let _0x2f4947 = "Multiple Payment Service";
          let _0x391904 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
          let _0x2ecfed = true;
          if (user_data.other_preferences.paymentmethod.includes("IRCUPI")) {
            _0x2ecfed = false;
            _0x2f4947 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
            _0x391904 = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
            console.log("Payment option-IRCUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("PAYTMUPI")) {
            _0x2f4947 = "BHIM/ UPI/ USSD";
            _0x391904 = "Pay using BHIM (Powered by PAYTM ) also accepts UPI";
            console.log("Payment option-PAYTMUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("PHONEPEUPI")) {
            _0x2f4947 = "Multiple Payment Service";
            _0x391904 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            console.log("Payment option-PHONEPEUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("MOBUPI")) {
            const _0x3f596d = window.navigator.userAgent;
            console.log("BrowserUserAgent", _0x3f596d);
            if (_0x3f596d.includes("Android")) {
              console.log("Android browser");
              _0x2f4947 = "Multiple Payment Service";
              _0x391904 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            }
          }
          if (user_data.other_preferences.paymentmethod.includes("IRCWA")) {
            _0x2f4947 = "IRCTC eWallet";
            _0x391904 = "IRCTC eWallet";
            console.log("Payment option-IRCWA");
          }
          if (user_data.other_preferences.paymentmethod.includes("HDFCDB")) {
            _0x2f4947 = "Payment Gateway / Credit Card / Debit Card";
            _0x391904 = "Visa/Master Card(Powered By HDFC BANK)";
            console.log("Payment option-HDFCDB");
          }
          let _0x297681 = _0x391904.replace('&', "&amp;");
          let _0xd41e3b = false;
          var _0xf642c6 = setInterval(() => {
            if (document.getElementsByClassName("bank-type").length > 0x1) {
              clearInterval(_0xf642c6);
              var _0x421b5d = document.getElementById("pay-type").getElementsByTagName("div");
              for (i = 0x0; i < _0x421b5d.length; i++) {
                if (_0x421b5d[i].innerText.indexOf(_0x2f4947) >= 0x0) {
                  if (_0x2ecfed) {
                    _0x421b5d[i].click();
                  }
                  setTimeout(() => {
                    var _0x5e31b3 = document.getElementsByClassName("border-all no-pad");
                    for (i = 0x0; i < _0x5e31b3.length; i++) {
                      if (0x0 != _0x5e31b3[i].getBoundingClientRect().top && -0x1 != _0x5e31b3[i].getElementsByTagName("span")[0x0].innerHTML.toUpperCase().indexOf(_0x297681.toUpperCase())) {
                        if (_0x2ecfed) {
                          _0x5e31b3[i].click();
                        }
                        _0xd41e3b = true;
                        document.getElementsByClassName("btn-primary")[0x0].scrollIntoView({
                          'behavior': "smooth",
                          'block': "center",
                          'inline': "nearest"
                        });
                        if (user_data.other_preferences.hasOwnProperty("paymentManual") && user_data.other_preferences.paymentManual) {
                          alert("Manually submit the payment page.");
                        } else {
                          setTimeout(() => {
                            document.getElementsByClassName("btn-primary")[0x0].click();
                          }, 0x1f4);
                        }
                        break;
                      }
                      if (!(i != _0x5e31b3.length - 0x1 || _0xd41e3b)) {
                        alert("Selected payment option not available, please select other option manually.");
                      }
                    }
                  }, 0x1f4);
                }
              }
            }
          }, 0x1f4);
        } else {
          console.log("Nothing to do");
        }
      }
    }
  }
  _0x175006("Something went wrong");
});
function getCaptcha() {
  if (captchaRetry < 0x64) {
    console.log("getCaptcha");
    captchaRetry += 0x1;
    const _0x707b0 = document.querySelector(".captcha-img");
    if (_0x707b0) {
      const _0x52ad74 = new XMLHttpRequest();
      const _0x222580 = _0x707b0.src.substr(0x16);
      const _0x416e97 = JSON.stringify({
        'requests': [{
          'image': {
            'content': _0x222580
          },
          'features': [{
            'type': "TEXT_DETECTION"
          }],
          'imageContext': {
            'languageHints': ['en']
          }
        }]
      });
      user_data.other_preferences.projectId;
      _0x52ad74.open("POST", "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDnvpf2Tusn2Cp2icvUjGBBbfn_tY86QgQ", false);
      _0x52ad74.onload = function () {
        if (0xc8 != _0x52ad74.status) {
          console.log("Error " + _0x52ad74.status + ": " + _0x52ad74.statusText);
          console.log(_0x52ad74.response);
        } else {
          let _0x132aed = '';
          const _0x59c4e2 = document.querySelector("#captcha");
          _0x132aed = JSON.parse(_0x52ad74.response).responses[0x0].fullTextAnnotation.text;
          console.log("Org text", _0x132aed);
          const _0x3f27e2 = Array.from(_0x132aed.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0x4fafcf = '';
          for (const _0x1d7856 of _0x3f27e2) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x1d7856)) {
            _0x4fafcf += _0x1d7856;
          }
          _0x59c4e2.value = _0x4fafcf;
          if ('' == _0x132aed) {
            console.log("Null captcha text from api");
            document.getElementsByClassName("glyphicon glyphicon-repeat")[0x0].parentElement.click();
            setTimeout(() => {
              getCaptcha();
            }, 0x1f4);
          }
          _0x59c4e2.dispatchEvent(new Event("input"));
          _0x59c4e2.dispatchEvent(new Event("change"));
          _0x59c4e2.focus();
          const _0x344b97 = document.querySelector("app-login");
          const _0xc2e688 = document.querySelector("#divMain > div > app-review-booking > p-toast");
          let _0x45bef2 = new MutationObserver(_0x5f188d => {
            if (_0x344b97 && _0x344b97.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptcha();
              }, 0x1f4);
              console.log("disconnect loginCaptcha");
              _0x45bef2.disconnect();
            }
            if (_0xc2e688 && _0xc2e688.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptcha();
              }, 0x1f4);
              console.log("disconnect reviewCaptcha");
              _0x45bef2.disconnect();
            }
          });
          if (_0x344b97) {
            console.log("observe loginCaptcha");
            _0x45bef2.observe(_0x344b97, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (_0xc2e688) {
            console.log("observe reviewCaptcha");
            _0x45bef2.observe(_0xc2e688, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
        }
      };
      _0x52ad74.onerror = function () {
        console.log("Captcha API Request failed");
      };
      _0x52ad74.send(_0x416e97);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptcha();
      }, 0x3e8);
    }
  }
}
let captchaRetry = 0x0;
function getCaptchaTC() {
  if (captchaRetry < 0x64) {
    console.log("getCaptchaTC");
    captchaRetry += 0x1;
    const _0x5d6e76 = document.querySelector(".captcha-img");
    if (_0x5d6e76) {
      const _0x343850 = new XMLHttpRequest();
      const _0x44da26 = _0x5d6e76.src.substr(0x16);
      const _0x3d1035 = JSON.stringify({
        'client': "chrome extension",
        'location': "https://www.irctc.co.in/nget/train-search",
        'version': "0.3.8",
        'case': "mixed",
        'promise': "true",
        'extension': true,
        'userid': "BOOKINGKING",
        'apikey': "ZGUT5Ogdhijd267r761q",
        'data': _0x44da26
      });
      _0x343850.open("POST", "https://api.apitruecaptcha.org/one/gettext", false);
      _0x343850.onload = function () {
        if (0xc8 != _0x343850.status) {
          console.log("Error " + _0x343850.status + ": " + _0x343850.statusText);
          console.log(_0x343850.response);
        } else {
          let _0x5f444e = '';
          const _0x76dc10 = document.querySelector("#captcha");
          _0x5f444e = JSON.parse(_0x343850.response).result;
          console.log("Org text", _0x5f444e);
          const _0x5e2c47 = Array.from(_0x5f444e.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0x24ae62 = '';
          for (const _0x83abc6 of _0x5e2c47) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x83abc6)) {
            _0x24ae62 += _0x83abc6;
          }
          _0x76dc10.value = _0x24ae62;
          if ('' == _0x5f444e) {
            console.log("Null captcha text from api");
            document.getElementsByClassName("glyphicon glyphicon-repeat")[0x0].parentElement.click();
            setTimeout(() => {
              getCaptchaTC();
            }, 0x1f4);
          }
          _0x76dc10.dispatchEvent(new Event("input"));
          _0x76dc10.dispatchEvent(new Event("change"));
          _0x76dc10.focus();
          const _0x27e9e7 = document.querySelector("app-login");
          const _0x3b5eaf = document.querySelector("#divMain > div > app-review-booking > p-toast");
          let _0xa9553b = new MutationObserver(_0x1a2923 => {
            if (_0x27e9e7 && _0x27e9e7.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect loginCaptcha");
              _0xa9553b.disconnect();
            }
            if (_0x3b5eaf && _0x3b5eaf.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect reviewCaptcha");
              _0xa9553b.disconnect();
            }
          });
          if (_0x27e9e7) {
            console.log("observe loginCaptcha");
            _0xa9553b.observe(_0x27e9e7, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (_0x3b5eaf) {
            console.log("observe reviewCaptcha");
            _0xa9553b.observe(_0x3b5eaf, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (undefined !== user_data.other_preferences.CaptchaSubmitMode && 'A' == user_data.other_preferences.CaptchaSubmitMode) {
            console.log("Auto submit captcha");
            const _0x51f894 = document.querySelector("#divMain > app-login");
            if (_0x51f894) {
              const _0x361214 = _0x51f894.querySelector("button[type='submit'][class='search_btn train_Search']");
              const _0x541cc0 = _0x51f894.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']");
              const _0x52a0bd = _0x51f894.querySelector("input[type='text'][formcontrolname='userid']");
              const _0x2299ca = _0x51f894.querySelector("input[type='password'][formcontrolname='password']");
              if ('' != _0x52a0bd.value && '' != _0x2299ca.value) {
                console.log("Submit login info and captcha");
                setTimeout(() => {
                  try {
                    _0x361214.click();
                  } catch (_0x30c34f) {}
                  try {
                    _0x541cc0.click();
                  } catch (_0x5035dd) {}
                }, 0x1f4);
              } else {
                alert("Unable to auto submit loging info, username and password not filled,please submit manually");
              }
            }
            reviewPage = document.querySelector("#divMain > div > app-review-booking");
            if (reviewPage) {
              console.log("reviewPage", reviewPage);
              if ('' != document.querySelector("#captcha").value) {
                const _0x292789 = document.querySelector(".btnDefault.train_Search");
                if (_0x292789) {
                  setTimeout(() => {
                    console.log("Confirm berth", user_data.other_preferences.confirmberths);
                    if (user_data.other_preferences.confirmberths) {
                      if (document.querySelector(".AVAILABLE")) {
                        console.log("Seats available");
                        _0x292789.click();
                      } else {
                        if (0x1 != confirm("No seats Available, Do you still want to continue booking?")) {
                          return void console.log("No Seats available, STOP");
                        }
                        console.log("No Seats available, still Go ahead");
                        _0x292789.click();
                      }
                    } else {
                      _0x292789.click();
                    }
                  }, 0x1f4);
                }
              } else {
                alert("Captcha automatically not filled, submit manually");
              }
            }
          } else {
            console.log("Manual captcha submission");
          }
        }
      };
      _0x343850.onerror = function () {
        console.log("Captcha API Request failed");
      };
      _0x343850.send(_0x3d1035);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptchaTC();
      }, 0x3e8);
    }
  }
}
function manualCaptchaEntry() {
  console.log("Switching to manual captcha entry");
  captchaRetry = 0x0;
  captchaAutosolveAttempts = 0x0;
  const _0x475702 = document.querySelector("#captcha");
  if (_0x475702) {
    _0x475702.value = '';
    try {
      _0x475702.focus();
    } catch (_0x2b7f05) {
      console.log("Could not focus captcha input:", _0x2b7f05);
    }
    const _0x47d9ff = _0x475702.closest("div");
    if (_0x47d9ff) {
      const _0x411533 = document.getElementById("manual-captcha-indicator");
      if (_0x411533) {
        _0x411533.remove();
      }
      const _0x249e75 = document.createElement("div");
      _0x249e75.id = "manual-captcha-indicator";
      _0x249e75.innerHTML = "\n        <div style=\"\n          background-color: #f8d7da;\n          color: #721c24;\n          padding: 10px;\n          margin: 10px 0;\n          border: 1px solid #f5c6cb;\n          border-radius: 4px;\n          font-weight: bold;\n          text-align: center;\n        \">\n          Automatic captcha solving failed. Please enter the captcha manually.\n        </div>\n      ";
      if (_0x47d9ff.firstChild) {
        _0x47d9ff.insertBefore(_0x249e75, _0x47d9ff.firstChild);
      } else {
        _0x47d9ff.appendChild(_0x249e75);
      }
      _0x475702.scrollIntoView({
        'behavior': "smooth",
        'block': "center"
      });
    }
  }
}
function processAndFillCaptcha(_0x1f6644) {
  if (!_0x1f6644 || _0x1f6644.trim() === '') {
    console.log("Empty captcha text received");
    manualCaptchaEntry();
    return;
  }
  console.log("Processing captcha text:", _0x1f6644);
  let _0x332710 = '';
  for (const _0xfc4376 of _0x1f6644) {
    if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0xfc4376)) {
      _0x332710 += _0xfc4376;
    }
  }
  if (_0x332710.length < 0x3) {
    console.log("Captcha text too short after cleaning:", _0x332710);
    manualCaptchaEntry();
    return;
  }
  console.log("Cleaned captcha text:", _0x332710);
  const _0x3a6e3c = document.querySelector("#captcha");
  if (!_0x3a6e3c) {
    console.error("Captcha input field not found");
    return;
  }
  _0x3a6e3c.value = _0x332710;
  _0x3a6e3c.dispatchEvent(new Event("input"));
  _0x3a6e3c.dispatchEvent(new Event("change"));
  try {
    _0x3a6e3c.focus();
  } catch (_0x4cd42e) {
    console.log("Could not focus captcha input:", _0x4cd42e);
  }
  console.log("Captcha field filled with:", _0x332710);
  captchaRetry = 0x0;
  captchaAutosolveAttempts = 0x0;
  const _0x106c60 = document.querySelector("app-login");
  const _0x157bf6 = document.querySelector("#divMain > div > app-review-booking > p-toast");
  let _0x324a74 = new MutationObserver(_0x11248c => {
    const _0x2c533e = _0x11248c.some(_0x2c86fb => {
      const _0x11c3f1 = _0x2c86fb.target.textContent.toLowerCase();
      return _0x11c3f1.includes("valid captcha") || _0x11c3f1.includes("invalid captcha");
    });
    if (_0x2c533e) {
      console.log("Invalid captcha detected, trying again");
      _0x324a74.disconnect();
      getCaptchaTC();
    }
  });
  if (_0x106c60) {
    console.log("Observing login page for captcha validation");
    _0x324a74.observe(_0x106c60, {
      'childList': true,
      'subtree': true,
      'characterData': true
    });
  }
  if (_0x157bf6) {
    console.log("Observing review page for captcha validation");
    _0x324a74.observe(_0x157bf6, {
      'childList': true,
      'subtree': true,
      'characterData': true
    });
  }
  if (user_data.other_preferences.CaptchaSubmitMode === 'A') {
    console.log("Auto submit captcha");
    const _0x4f517f = document.querySelector("#divMain > app-login");
    if (_0x4f517f) {
      const _0x3b43ce = _0x4f517f.querySelector("button[type='submit'][class='search_btn train_Search']");
      const _0x5979e4 = _0x4f517f.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']");
      const _0x22b6cf = _0x4f517f.querySelector("input[type='text'][formcontrolname='userid']");
      const _0x4e8e88 = _0x4f517f.querySelector("input[type='password'][formcontrolname='password']");
      if (_0x22b6cf.value !== '' && _0x4e8e88.value !== '') {
        console.log("Submit login info and captcha");
        setTimeout(() => {
          try {
            if (_0x3b43ce) {
              _0x3b43ce.click();
            }
          } catch (_0x589519) {
            console.error("Error clicking submit button:", _0x589519);
          }
          try {
            if (_0x5979e4) {
              _0x5979e4.click();
            }
          } catch (_0x2926cc) {
            console.error("Error clicking alternate submit button:", _0x2926cc);
          }
        }, 0x1f4);
      } else {
        alert("Unable to auto submit login info, username and password not filled, please submit manually");
      }
    }
    const _0x2c2a23 = document.querySelector("#divMain > div > app-review-booking");
    if (_0x2c2a23) {
      console.log("On review page");
      if (document.querySelector('#captcha').value !== '') {
        const _0x4ae49c = document.querySelector(".btnDefault.train_Search");
        if (_0x4ae49c) {
          setTimeout(() => {
            if (user_data.other_preferences.confirmberths) {
              console.log("Confirm berth:", user_data.other_preferences.confirmberths);
              if (document.querySelector(".AVAILABLE")) {
                console.log("Seats available");
                _0x4ae49c.click();
              } else if (confirm("No seats Available, Do you still want to continue booking?")) {
                console.log("No Seats available, continuing anyway");
                _0x4ae49c.click();
              } else {
                console.log("No Seats available, stopping");
              }
            } else {
              _0x4ae49c.click();
            }
          }, 0x1f4);
        }
      } else {
        alert("Captcha automatically not filled, submit manually");
      }
    }
  } else {
    console.log("Manual captcha submission");
  }
}
function loadLoginDetails() {
  const _0x3dd92d = document.querySelector("#divMain > app-login");
  const _0x2928df = _0x3dd92d.querySelector("input[type='text'][formcontrolname='userid']");
  const _0x2a4e9e = _0x3dd92d.querySelector("input[type='password'][formcontrolname='password']");
  _0x3dd92d.querySelector("button[type='submit']");
  _0x2928df.value = user_data.irctc_credentials.user_name ?? '';
  _0x2928df.dispatchEvent(new Event("input"));
  _0x2928df.dispatchEvent(new Event("change"));
  _0x2a4e9e.value = user_data.irctc_credentials.password ?? '';
  _0x2a4e9e.dispatchEvent(new Event("input"));
  _0x2a4e9e.dispatchEvent(new Event("change"));
  document.querySelector("#captcha").scrollIntoView({
    'behavior': "smooth",
    'block': "center",
    'inline': "nearest"
  });
  if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
    setTimeout(() => {
      getCaptchaTC();
    }, 0x1f4);
  } else {
    console.log("Manual captcha filling");
    const _0xc5b93 = document.querySelector("#captcha");
    _0xc5b93.value = 'X';
    _0xc5b93.dispatchEvent(new Event("input"));
    _0xc5b93.dispatchEvent(new Event("change"));
    _0xc5b93.focus();
  }
}
function loadJourneyDetails() {
  console.log("filling_journey_details");
  const _0x54b90b = document.querySelector("app-jp-input form");
  const _0x1bcb2e = _0x54b90b.querySelector("#origin > span > input");
  _0x1bcb2e.value = user_data.journey_details.from;
  _0x1bcb2e.dispatchEvent(new Event("keydown"));
  _0x1bcb2e.dispatchEvent(new Event("input"));
  const _0x3052d1 = _0x54b90b.querySelector("#destination > span > input");
  _0x3052d1.value = user_data.journey_details.destination;
  _0x3052d1.dispatchEvent(new Event("keydown"));
  _0x3052d1.dispatchEvent(new Event("input"));
  const _0x45ea11 = _0x54b90b.querySelector("#jDate > span > input");
  _0x45ea11.value = user_data.journey_details.date ? '' + user_data.journey_details.date.split('-').reverse().join('/') : '';
  _0x45ea11.dispatchEvent(new Event("keydown"));
  _0x45ea11.dispatchEvent(new Event('input'));
  const _0x1e58f5 = _0x54b90b.querySelector("#journeyClass");
  _0x1e58f5.querySelector("div > div[role='button']").click();
  addDelay(0x12c);
  [..._0x1e58f5.querySelectorAll("ul li")].filter(_0x36c131 => _0x36c131.innerText === classTranslator(user_data.journey_details["class"]) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x2712ea = _0x54b90b.querySelector("#journeyQuota");
  _0x2712ea.querySelector("div > div[role='button']").click();
  [..._0x2712ea.querySelectorAll("ul li")].filter(_0x195f49 => _0x195f49.innerText === quotaTranslator(user_data.journey_details.quota) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x4baf2a = _0x54b90b.querySelector("button.search_btn.train_Search[type='submit']");
  addDelay(0x12c);
  console.log("filled_journey_details");
  _0x4baf2a.click();
}
function selectJourneyOld() {
  if (!user_data.journey_details["train-no"]) {
    return;
  }
  const _0x372e6e = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
  console.log(user_data.journey_details["train-no"]);
  const _0x51beaa = _0x372e6e.filter(_0x20eed6 => _0x20eed6.querySelector("div.train-heading").innerText.trim().includes(user_data.journey_details["train-no"]))[0x0];
  if (!_0x51beaa) {
    console.log("Train not found.");
    alert("Train not found");
    return void statusUpdate("journey_selection_stopped.no_train");
  }
  const _0xa60492 = classTranslator(user_data.journey_details["class"]);
  const _0x3f57a1 = new Date(user_data.journey_details.date).toString().split(" ");
  const _0x4ee5a2 = {
    'attributes': false,
    'childList': true,
    'subtree': true
  };
  [..._0x51beaa.querySelectorAll("table tr td div.pre-avl")].filter(_0x33e59c => _0x33e59c.querySelector("div").innerText === _0xa60492)[0x0]?.["click"]();
  const _0x517c27 = document.querySelector("#divMain > div > app-train-list > p-toast");
  new MutationObserver((_0x8e1849, _0x24b264) => {
    const _0x18b304 = [..._0x51beaa.querySelectorAll("div p-tabmenu ul[role='tablist'] li[role='tab']")].filter(_0x594c33 => _0x594c33.querySelector("div").innerText === _0xa60492)[0x0];
    const _0x517b3c = [..._0x51beaa.querySelectorAll("div div table td div.pre-avl")].filter(_0x3d0abb => _0x3d0abb.querySelector("div").innerText === _0x3f57a1[0x0] + ", " + _0x3f57a1[0x2] + " " + _0x3f57a1[0x1])[0x0];
    const _0x28eec3 = _0x51beaa.querySelector("button.btnDefault.train_Search.ng-star-inserted");
    if (_0x18b304) {
      console.log(0x1);
      if (!_0x18b304.classList.contains("ui-state-active")) {
        console.log(0x2);
        return void _0x18b304.click();
      }
      if (_0x517b3c) {
        console.log(0x3);
        if (_0x517b3c.classList.contains("selected-class")) {
          console.log(0x4);
          _0x28eec3.click();
          _0x24b264.disconnect();
        } else {
          console.log(0x5);
          _0x517b3c.click();
        }
      }
    } else {
      console.log('6');
      _0x517b3c.click();
      _0x28eec3.click();
      _0x24b264.disconnect();
    }
  }).observe(_0x51beaa, _0x4ee5a2);
  const _0x1ad50a = new MutationObserver((_0x385ebc, _0x73f5a8) => {
    console.log("Popup error");
    console.log("Class count ", [..._0x51beaa.querySelectorAll("table tr td div.pre-avl")].length);
    console.log("Class count ", [..._0x51beaa.querySelectorAll("table tr td div.pre-avl")]);
    if (_0x517c27.innerText.includes("Unable to perform")) {
      console.log("Unable to perform");
      [..._0x51beaa.querySelectorAll("table tr td div.pre-avl")].filter(_0x5177a4 => _0x5177a4.querySelector("div").innerText === _0xa60492)[0x0]?.["click"]();
      _0x73f5a8.disconnect();
    }
  });
  _0x1ad50a.observe(_0x517c27, _0x4ee5a2);
}
function retrySelectJourney() {
  console.log("Retrying selectJourney...");
  setTimeout(selectJourney, 0x3e8);
}
function selectJourney() {
  const _0x3e0d23 = setInterval(() => {
    const _0xcfe286 = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a");
    const _0x11e21e = document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
    const _0x50bdcd = _0xcfe286 || _0x11e21e;
    const _0x6f61f = document.querySelector("#loaderP");
    const _0x14e803 = _0x6f61f && "none" !== _0x6f61f.style.display;
    if (_0x50bdcd && !_0x14e803) {
      console.log("Toast link found. Clicking it now...");
      _0x50bdcd.click();
      console.log("Toast link clicked");
      retrySelectJourney();
      console.log("Toast link clicked and called retrySelectJourney");
      clearInterval(_0x3e0d23);
    }
  }, 0x3e8);
  if (!user_data?.["journey_details"]?.["train-no"]) {
    return void console.error("Train number is not available in user_data.");
  }
  const _0x2ed75a = document.querySelector("#divMain > div > app-train-list");
  if (!_0x2ed75a) {
    return void console.error("Train list parent not found.");
  }
  const _0x3a818e = Array.from(_0x2ed75a.querySelectorAll(".tbis-div app-train-avl-enq"));
  const _0x4c1cc1 = user_data.journey_details["train-no"];
  const _0x7c94d8 = classTranslator(user_data.journey_details["class"]);
  const _0x855b1f = new Date(user_data.journey_details.date);
  const _0x1f061a = _0x855b1f.toDateString().split(" ")[0x0] + ", " + _0x855b1f.toDateString().split(" ")[0x2] + " " + _0x855b1f.toDateString().split(" ")[0x1];
  console.log("Train Number:", _0x4c1cc1);
  console.log("Class:", _0x7c94d8);
  console.log('date', _0x1f061a);
  const _0x2688a9 = _0x3a818e.find(_0x570f36 => _0x570f36.querySelector("div.train-heading").innerText.trim().includes(_0x4c1cc1.split('-')[0x0]));
  if (!_0x2688a9) {
    console.error("Train not found.");
    return void statusUpdate("journey_selection_stopped.no_train");
  }
  const _0x2f7af1 = _0x4f8395 => {
    if (!_0x4f8395) {
      return false;
    }
    const _0x5a430f = window.getComputedStyle(_0x4f8395);
    return "none" !== _0x5a430f.display && "hidden" !== _0x5a430f.visibility && '0' !== _0x5a430f.opacity;
  };
  const _0x1d6b69 = Array.from(_0x2688a9.querySelectorAll("table tr td div.pre-avl")).find(_0xce74e6 => _0xce74e6.querySelector("div").innerText.trim() === _0x7c94d8);
  const _0x3691df = Array.from(_0x2688a9.querySelectorAll("span")).find(_0x42cecb => _0x42cecb.innerText.trim() === _0x7c94d8);
  const _0x484235 = _0x1d6b69 || _0x3691df;
  console.log("FOUND updatedClassToClick:", _0x484235);
  if (!_0x484235) {
    return void console.error("Class to click not found.");
  }
  const _0x2cac8a = document.querySelector("#loaderP");
  if (_0x2f7af1(_0x2cac8a)) {
    return void console.error("Loader is visible. Cannot click the class.");
  }
  let _0x338546;
  _0x484235.click();
  new MutationObserver((_0x26c6be, _0x379b67) => {
    console.log("Mutation observed at", new Date().toLocaleTimeString());
    clearTimeout(_0x338546);
    _0x338546 = setTimeout(() => {
      const _0x2e5f5b = Array.from(_0x2688a9.querySelectorAll("div div table td div.pre-avl")).find(_0x36dfa3 => _0x36dfa3.querySelector("div").innerText.trim() === _0x1f061a);
      console.log("FOUND classTabToSelect:", _0x2e5f5b);
      if (_0x2e5f5b) {
        _0x2e5f5b.click();
        console.log("Clicked on selectdate");
        setTimeout(() => {
          const _0x5338ea = () => {
            const _0x55b833 = _0x2688a9.querySelector("button.btnDefault.train_Search.ng-star-inserted");
            if (_0x2f7af1(document.querySelector("#loaderP"))) {
              console.warn("Loader is visible, retrying...");
              return void setTimeout(_0x5338ea, 0x64);
            }
            if (!_0x55b833 || _0x55b833.classList.contains("disable-book") || _0x55b833.disabled) {
              console.warn("bookBtn is disabled or not found, retrying...");
              retrySelectJourney();
            } else {
              setTimeout(() => {
                _0x55b833.click();
                console.log("Clicked on bookBtn");
                clearTimeout(_0x338546);
                _0x379b67.disconnect();
              }, 0x12c);
            }
          };
          _0x5338ea();
        }, 0x3e8);
      } else {
        console.warn("classTabToSelect not found");
      }
    }, 0x12c);
  }).observe(_0x2688a9, {
    'attributes': false,
    'childList': true,
    'subtree': true
  });
}
let keyCounter = 0x0;
function fillPassengerDetails() {
  console.log("passenger_filling_started");
  if (user_data.journey_details.boarding.length > 0x0) {
    console.log("Set boarding station " + user_data.journey_details.boarding);
    const _0xa2643d = document.getElementsByTagName('strong');
    const _0x7b10ae = Array.from(_0xa2643d).filter(_0x149565 => _0x149565.innerText.includes(user_data.journey_details.from.split('-')[0x0].trim() + " | "));
    if (_0x7b10ae[0x0]) {
      _0x7b10ae[0x0].click();
      addDelay(0x12c);
    }
    const _0x20d1f8 = document.getElementsByTagName("strong");
    const _0x525ca4 = Array.from(_0x20d1f8).filter(_0x4195fd => _0x4195fd.innerText.includes(user_data.journey_details.boarding.split('-')[0x0].trim()));
    if (_0x525ca4[0x0]) {
      _0x525ca4[0x0].click();
    }
  }
  keyCounter = new Date().getTime();
  const _0x1980e2 = document.querySelector("app-passenger-input");
  let _0xe734dc = 0x1;
  for (; _0xe734dc < user_data.passenger_details.length;) {
    addDelay(0xc8);
    document.getElementsByClassName("prenext")[0x0].click();
    _0xe734dc++;
  }
  try {
    let _0xde0a2a = 0x0;
    for (; _0xde0a2a < user_data.infant_details.length;) {
      addDelay(0xc8);
      document.getElementsByClassName("prenext")[0x2].click();
      _0xde0a2a++;
    }
  } catch (_0x52b9d2) {
    console.error("add infant error", _0x52b9d2);
  }
  const _0x88cbcb = [..._0x1980e2.querySelectorAll("app-passenger")];
  const _0x2a84ce = [..._0x1980e2.querySelectorAll("app-infant")];
  user_data.passenger_details.forEach((_0x1d3b3d, _0x148364) => {
    let _0x13de4c = _0x88cbcb[_0x148364].querySelector("p-autocomplete > span > input");
    _0x13de4c.value = _0x1d3b3d.name;
    _0x13de4c.dispatchEvent(new Event("input"));
    let _0x437ef2 = _0x88cbcb[_0x148364].querySelector("input[type='number'][formcontrolname='passengerAge']");
    _0x437ef2.value = _0x1d3b3d.age;
    _0x437ef2.dispatchEvent(new Event("input"));
    let _0x38398d = _0x88cbcb[_0x148364].querySelector("select[formcontrolname='passengerGender']");
    _0x38398d.value = _0x1d3b3d.gender;
    _0x38398d.dispatchEvent(new Event("change"));
    let _0x4f50d6 = _0x88cbcb[_0x148364].querySelector("select[formcontrolname='passengerBerthChoice']");
    _0x4f50d6.value = _0x1d3b3d.berth;
    _0x4f50d6.dispatchEvent(new Event("change"));
    let _0x1f7dc1 = _0x88cbcb[_0x148364].querySelector("select[formcontrolname='passengerFoodChoice']");
    if (_0x1f7dc1) {
      _0x1f7dc1.value = _0x1d3b3d.food;
      _0x1f7dc1.dispatchEvent(new Event("change"));
    }
    try {
      let _0x9bcd6 = _0x88cbcb[_0x148364].querySelector("input[type='checkbox'][formcontrolname='childBerthFlag']");
      console.log("noChildberth", _0x148364, _0x1d3b3d.passengerchildberth);
      if (_0x9bcd6 && _0x1d3b3d.passengerchildberth) {
        console.log("set child half seat");
        _0x9bcd6.click();
        addDelay(0xc8);
        if (document.evaluate("//div[contains(text(),'No berth will be allotted for child and')]", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
          console.log("clikc OK");
          document.querySelector("app-passenger > p-dialog > div > div > div > p-footer > button").click();
          addDelay(0xc8);
        }
      }
    } catch (_0x554445) {
      console.error("opt Half seat error", _0x554445);
    }
  });
  try {
    user_data.infant_details.forEach((_0x481963, _0x4108cb) => {
      let _0x2b2e51 = _0x2a84ce[_0x4108cb].querySelector("input#infant-name[name='infant-name']");
      _0x2b2e51.value = _0x481963.name;
      _0x2b2e51.dispatchEvent(new Event("input"));
      let _0x2c1b48 = _0x2a84ce[_0x4108cb].querySelector("select[formcontrolname='age']");
      _0x2c1b48.value = _0x481963.age;
      _0x2c1b48.dispatchEvent(new Event("change"));
      let _0x2b3602 = _0x2a84ce[_0x4108cb].querySelector("select[formcontrolname='gender']");
      _0x2b3602.value = _0x481963.gender;
      _0x2b3602.dispatchEvent(new Event("change"));
    });
  } catch (_0x1c911e) {
    console.error("fill infant error", _0x1c911e);
  }
  if ('' !== user_data.other_preferences.mobileNumber) {
    let _0x51660a = _0x1980e2.querySelector("input#mobileNumber[formcontrolname='mobileNumber'][name='mobileNumber']");
    _0x51660a.value = user_data.other_preferences.mobileNumber;
    _0x51660a.dispatchEvent(new Event("input"));
  }
  let _0x5f9adc = [..._0x1980e2.querySelectorAll("p-radiobutton[formcontrolname='paymentType'][name='paymentType'] input[type='radio']")];
  addDelay(0x64);
  let _0xd08553 = '2';
  if (!user_data.other_preferences.paymentmethod.includes("UPI")) {
    _0xd08553 = 0x1;
  }
  _0x5f9adc.filter(_0xfcc8b8 => _0xfcc8b8.value === _0xd08553)[0x0]?.["click"]();
  let _0x18dc0b = _0x1980e2.querySelector("input#autoUpgradation[type='checkbox'][formcontrolname='autoUpgradationSelected']");
  if (_0x18dc0b && user_data.other_preferences.hasOwnProperty("autoUpgradation") && user_data.other_preferences.autoUpgradation) {
    _0x18dc0b.checked = user_data.other_preferences.autoUpgradation ?? false;
  }
  let _0x470db3 = _0x1980e2.querySelector("input#confirmberths[type='checkbox'][formcontrolname='bookOnlyIfCnf']");
  if (_0x470db3 && user_data.other_preferences.hasOwnProperty("confirmberths") && user_data.other_preferences.confirmberths) {
    _0x470db3.checked = user_data.other_preferences.confirmberths ?? false;
  }
  let _0xdb6e14 = [..._0x1980e2.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input[type='radio'][name='travelInsuranceOpted-0']")];
  addDelay(0xc8);
  _0xdb6e14.filter(_0x1d7426 => _0x1d7426.value === ("yes" === user_data.travel_preferences.travelInsuranceOpted ? "true" : "false"))[0x0]?.['click']();
  try {
    let _0x340206 = _0x1980e2.querySelector("input[formcontrolname='coachId']");
    if (_0x340206 && user_data.travel_preferences.hasOwnProperty("prefcoach") && user_data.travel_preferences.prefcoach.trim().length > 0x0) {
      console.log("set preferred coach Id");
      _0x340206.value = user_data.travel_preferences.prefcoach;
    }
    const _0x86d0c4 = _0x1980e2.querySelector("p-dropdown[formcontrolname='reservationChoice']");
    if (_0x86d0c4 && user_data.travel_preferences.hasOwnProperty("reservationchoice") && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
      console.log("set reservationchoice");
      _0x86d0c4.querySelector("div > div[role='button']").click();
      addDelay(0x12c);
      [..._0x86d0c4.querySelectorAll("ul li")].filter(_0x168e66 => _0x168e66.innerText === user_data.travel_preferences.reservationchoice ?? '')[0x0]?.["click"]();
    }
  } catch (_0x4f2199) {
    console.error("pref coach and reservation choice error", _0x4f2199);
  }
  submitPassengerDetailsForm(_0x1980e2);
}
function submitPassengerDetailsForm(_0x1b07a3) {
  console.log("passenger_filling_completed");
  window.scrollBy(0x0, 0x258, "smooth");
  if (user_data.other_preferences.hasOwnProperty("psgManual") && user_data.other_preferences.psgManual) {
    alert("Manually submit the passenger page.");
  } else {
    var _0x1cdd30 = setInterval(function () {
      var _0x33949c = new Date().getTime();
      if (keyCounter > 0x0 && _0x33949c - keyCounter > 0x7d0) {
        clearInterval(_0x1cdd30);
        _0x1b07a3.querySelector("#psgn-form > form div > button.train_Search.btnDefault[type='submit']")?.["click"]();
        window.scrollBy(0x0, 0x258, "smooth");
      }
    }, 0x1f4);
  }
}
function continueScript() {
  const _0x34ec0e = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted");
  if (window.location.href.includes("train-search")) {
    if ("LOGOUT" === _0x34ec0e.innerText.trim().toUpperCase()) {
      loadJourneyDetails();
    }
    if ("LOGIN" === _0x34ec0e.innerText.trim().toUpperCase()) {
      _0x34ec0e.click();
      loadLoginDetails();
    }
  } else if (!window.location.href.includes("nget/booking/train-list")) {
    console.log("Nothing to do");
  }
}
async function a() {
  const _0x25e4a3 = user_data.subs_credentials.user_name ?? '';
  console.log("Simulating plan check for:", _0x25e4a3);
  console.log("Fake plan check successful. Continuing...");
}
window.onload = function (_0x507dbb) {
  setInterval(function () {
    console.log("Repeater");
    statusUpdate("Keep listener alive.");
  }, 0x3a98);
  const _0x196868 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 ");
  new MutationObserver((_0x292281, _0x42adf8) => {
    if (_0x292281.filter(_0x2af442 => "childList" === _0x2af442.type && _0x2af442.addedNodes.length > 0x0 && [..._0x2af442.addedNodes].filter(_0x3e9d69 => "LOGOUT" === _0x3e9d69?.["innerText"]?.["trim"]()?.["toUpperCase"]()).length > 0x0).length > 0x0) {
      _0x42adf8.disconnect();
      loadJourneyDetails();
    } else {
      _0x196868.click();
      loadLoginDetails();
    }
  }).observe(_0x196868, {
    'attributes': false,
    'childList': true,
    'subtree': false
  });
  chrome.storage.local.get(null, _0x2891a8 => {
    user_data = _0x2891a8;
    continueScript();
  });
};
